#include <Arduino.h>
#include <U8g2lib.h>
#include <Wire.h>

U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, U8X8_PIN_NONE);

void setup() {
  Wire.setSDA(4);
  Wire.setSCL(5);
  Wire.begin();

  u8g2.begin();
}

void loop() {
  u8g2.clearBuffer();

  u8g2.setFont(u8g2_font_ncenB14_tr); 
  
  u8g2.drawStr(10, 40, "Group 31"); 

  u8g2.sendBuffer();          
  
  delay(1000);
}