#include <Arduino.h>
#include <U8g2lib.h>
#include <Wire.h>

U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, U8X8_PIN_NONE);

const int micPin = 26;
int sensitivity = 15; 

int graphData[128]; 

float smoothedValue = 0; 

void setup() {
  Wire.setSDA(4);
  Wire.setSCL(5);
  Wire.begin();
  u8g2.begin();
  analogReadResolution(12);

  for(int i = 0; i < 128; i++) {
    graphData[i] = 63; 
  }
}

void loop() {
  long sum = 0;
  int n = 150; 
  
  for(int i=0; i<n; i++) {
    sum += analogRead(micPin);
  }
  int rawValue = sum / n;

  int quietPoint = 2048; 
  int noiseThreshold = 15;

  int audioLevel = abs(rawValue - quietPoint);

  if (audioLevel < noiseThreshold) {
    audioLevel = 0;
  }

  audioLevel *= sensitivity;
  audioLevel = constrain(audioLevel, 0, 1000);

  smoothedValue = (smoothedValue * 0.9) + (audioLevel * 0.1);

  int plotY = map(audioLevel, 0, 1000, 63, 12);

  if (plotY < 12) plotY = 12; 
  if (plotY > 63) plotY = 63; 

  for (int i = 0; i < 127; i++) {
    graphData[i] = graphData[i+1];    
  }
  
  graphData[127] = plotY;

  u8g2.clearBuffer();
  
  u8g2.setFont(u8g2_font_6x10_tr);

  char buf[20];
  sprintf(buf, " Value: %4d", (int)smoothedValue);

  u8g2.drawStr(0, 10, buf);
  u8g2.drawHLine(0, 12, 128); 

  for (int x = 0; x < 127; x++) {
    u8g2.drawLine(x, graphData[x], x + 1, graphData[x+1]);
  }
  
  u8g2.sendBuffer();
  
  delay(10);
}